"""Automated tests for every route of the Todo API.

Run locally:   pip install -r requirements-dev.txt
               python automationTesting.py        (or: pytest automationTesting.py -v)
Run in CI:     see .github/workflows/ActionsYaml.yaml
"""
import os
import sqlite3
import sys
import tempfile

# Use a throw-away database so tests never touch real data.
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["DB_PATH"] = _tmp.name

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402

client = TestClient(main.app)


@pytest.fixture(autouse=True)
def clean_db():
    """Empty the table (and reset ids) before every test."""
    conn = sqlite3.connect(os.environ["DB_PATH"])
    conn.execute("DELETE FROM todos")
    conn.execute("DELETE FROM sqlite_sequence WHERE name = 'todos'")
    conn.commit()
    conn.close()
    yield


def make_todo(title="Learn Docker", **extra):
    resp = client.post("/todos", json={"title": title, **extra})
    assert resp.status_code == 201
    return resp.json()


# ----------------------------------------------------------- GET /  & /health
def test_root():
    resp = client.get("/")
    assert resp.status_code == 200
    assert resp.json()["status"] == "running"


def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "healthy"}


# ------------------------------------------------------------------ POST /todos
def test_create_todo():
    resp = client.post("/todos", json={"title": "Write report", "description": "PBL"})
    assert resp.status_code == 201
    body = resp.json()
    assert body["id"] == 1
    assert body["title"] == "Write report"
    assert body["description"] == "PBL"
    assert body["completed"] is False


def test_create_todo_missing_title_returns_422():
    assert client.post("/todos", json={"description": "no title"}).status_code == 422


def test_create_todo_empty_title_returns_422():
    assert client.post("/todos", json={"title": ""}).status_code == 422


# ------------------------------------------------------------------- GET /todos
def test_list_todos_empty():
    resp = client.get("/todos")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_todos_returns_all():
    make_todo("A")
    make_todo("B")
    resp = client.get("/todos")
    assert resp.status_code == 200
    assert [t["title"] for t in resp.json()] == ["A", "B"]


def test_list_todos_filter_completed():
    make_todo("open")
    make_todo("done", completed=True)
    done = client.get("/todos", params={"completed": "true"}).json()
    open_ = client.get("/todos", params={"completed": "false"}).json()
    assert [t["title"] for t in done] == ["done"]
    assert [t["title"] for t in open_] == ["open"]


# -------------------------------------------------------------- GET /todos/{id}
def test_get_todo_by_id():
    created = make_todo("Find me")
    resp = client.get(f"/todos/{created['id']}")
    assert resp.status_code == 200
    assert resp.json()["title"] == "Find me"


def test_get_todo_not_found():
    assert client.get("/todos/999").status_code == 404


def test_get_todo_invalid_id_returns_422():
    assert client.get("/todos/abc").status_code == 422


# -------------------------------------------------------------- PUT /todos/{id}
def test_update_todo_full():
    created = make_todo("Old")
    resp = client.put(
        f"/todos/{created['id']}",
        json={"title": "New", "description": "changed", "completed": True},
    )
    assert resp.status_code == 200
    assert resp.json() == {
        "id": created["id"], "title": "New", "description": "changed", "completed": True,
    }


def test_update_todo_partial_keeps_other_fields():
    created = make_todo("Keep", description="stay")
    resp = client.put(f"/todos/{created['id']}", json={"completed": True})
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "Keep"
    assert body["description"] == "stay"
    assert body["completed"] is True
    # and it was really persisted
    assert client.get(f"/todos/{created['id']}").json()["completed"] is True


def test_update_todo_not_found():
    assert client.put("/todos/999", json={"title": "x"}).status_code == 404


def test_update_todo_empty_title_returns_422():
    created = make_todo()
    assert client.put(f"/todos/{created['id']}", json={"title": ""}).status_code == 422


# ----------------------------------------------------------- DELETE /todos/{id}
def test_delete_todo():
    created = make_todo("Bye")
    assert client.delete(f"/todos/{created['id']}").status_code == 204
    assert client.get(f"/todos/{created['id']}").status_code == 404


def test_delete_todo_not_found():
    assert client.delete("/todos/999").status_code == 404


# ------------------------------------------------------------ full CRUD journey
def test_full_crud_flow():
    created = make_todo("Journey")
    tid = created["id"]
    assert client.get(f"/todos/{tid}").status_code == 200
    assert client.put(f"/todos/{tid}", json={"completed": True}).status_code == 200
    assert client.delete(f"/todos/{tid}").status_code == 204
    assert client.get("/todos").json() == []


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
