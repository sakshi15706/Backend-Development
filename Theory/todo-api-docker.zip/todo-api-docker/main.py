"""Todo API (FastAPI + SQLite) - PBL project for Unit 4: Docker, Compose, CI/CD.

Includes the monitoring pieces from the tutorial:
  * structured request logging middleware
  * /health endpoint for liveness checks
"""
import logging
import os
import sqlite3
import time
from contextlib import closing
from typing import Optional

from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel, Field

DB_PATH = os.getenv("DB_PATH", "todos.db")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("todo-api")

app = FastAPI(title="Todo API - FastAPI", version="1.0.0")


# ---------------------------------------------------------------- database
def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with closing(get_conn()) as conn, conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS todos (
                   id          INTEGER PRIMARY KEY AUTOINCREMENT,
                   title       TEXT    NOT NULL,
                   description TEXT    NOT NULL DEFAULT '',
                   completed   INTEGER NOT NULL DEFAULT 0
               )"""
        )


def row_to_dict(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "description": row["description"],
        "completed": bool(row["completed"]),
    }


init_db()


# ----------------------------------------------------------------- schemas
class TodoCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str = Field("", max_length=1000)
    completed: bool = False


class TodoUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    completed: Optional[bool] = None


# -------------------------------------------------------------- middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        duration_ms = (time.perf_counter() - start) * 1000
        logger.exception(
            "method=%s path=%s status=500 duration_ms=%.2f",
            request.method, request.url.path, duration_ms,
        )
        raise
    duration_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "method=%s path=%s status=%s duration_ms=%.2f",
        request.method, request.url.path, response.status_code, duration_ms,
    )
    return response


# ------------------------------------------------------------------ routes
@app.get("/")
def root():
    return {"application": "Todo API", "framework": "FastAPI", "status": "running"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/todos")
def list_todos(completed: Optional[bool] = None):
    query, params = "SELECT * FROM todos", ()
    if completed is not None:
        query += " WHERE completed = ?"
        params = (int(completed),)
    query += " ORDER BY id"
    with closing(get_conn()) as conn:
        return [row_to_dict(r) for r in conn.execute(query, params).fetchall()]


@app.post("/todos", status_code=201)
def create_todo(todo: TodoCreate):
    with closing(get_conn()) as conn, conn:
        cur = conn.execute(
            "INSERT INTO todos (title, description, completed) VALUES (?, ?, ?)",
            (todo.title, todo.description, int(todo.completed)),
        )
        new_id = cur.lastrowid
        row = conn.execute("SELECT * FROM todos WHERE id = ?", (new_id,)).fetchone()
    return row_to_dict(row)


@app.get("/todos/{todo_id}")
def get_todo(todo_id: int):
    with closing(get_conn()) as conn:
        row = conn.execute("SELECT * FROM todos WHERE id = ?", (todo_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Todo not found")
    return row_to_dict(row)


@app.put("/todos/{todo_id}")
def update_todo(todo_id: int, update: TodoUpdate):
    with closing(get_conn()) as conn, conn:
        row = conn.execute("SELECT * FROM todos WHERE id = ?", (todo_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Todo not found")
        current = row_to_dict(row)
        changes = update.model_dump(exclude_unset=True)
        # A null title would violate NOT NULL; ignore explicit nulls.
        changes = {k: v for k, v in changes.items() if v is not None}
        current.update(changes)
        conn.execute(
            "UPDATE todos SET title = ?, description = ?, completed = ? WHERE id = ?",
            (current["title"], current["description"], int(current["completed"]), todo_id),
        )
    return current


@app.delete("/todos/{todo_id}", status_code=204)
def delete_todo(todo_id: int):
    with closing(get_conn()) as conn, conn:
        cur = conn.execute("DELETE FROM todos WHERE id = ?", (todo_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Todo not found")
    return Response(status_code=204)
