# PBL Report — Containerizing a Todo API and Automating Test → Build → Push

**Course:** Backend Development — Unit 4
**Name / SAP ID:** `<your name>` / `<your SAP ID>`
**Repository:** `<link to your GitHub repo>`
**Docker Hub image:** `<link to https://hub.docker.com/r/<user>/todo-api>`

---

## 1. Objective

Replace the tutorial's sample Student API with my own project and:

1. Containerize it with a `Dockerfile`.
2. Run it with `docker-compose.yml`.
3. Write `automationTesting.py` covering every route.
4. Create a GitHub Actions workflow that **tests first**, then **builds and pushes**
   the image to Docker Hub.

## 2. Application chosen

A **Todo REST API** written in FastAPI with SQLite storage (Python standard-library
`sqlite3`). It reuses the monitoring ideas from the tutorial: a structured request-logging
middleware (`method= path= status= duration_ms=`) and a `/health` endpoint.

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/` | App info |
| GET | `/health` | Liveness check |
| GET | `/todos` | List (optional `completed` filter) |
| POST | `/todos` | Create (201) |
| GET | `/todos/{id}` | Read (404 if missing) |
| PUT | `/todos/{id}` | Update, partial allowed (404 if missing) |
| DELETE | `/todos/{id}` | Delete (204, 404 if missing) |

## 3. Design

### 3.1 Dockerfile
| Decision | Reason |
|----------|--------|
| `python:3.12-slim` base | Small, fast, reproducible |
| Copy `requirements.txt` before code | Dependency layer is cached; rebuilds are faster |
| Only `main.py` copied into the image | Tests and docs are not needed at runtime |
| Non-root `appuser` | Limits damage if the container is compromised |
| `DB_PATH=/data/todos.db` + `/data` volume | Data outlives the container |
| `HEALTHCHECK` on `/health` | Docker can report `healthy` / `unhealthy` |
| `.dockerignore` | Keeps `.env`, `.git`, tests and DB files out of the image |

### 3.2 docker-compose.yml
One `api` service: builds the local Dockerfile, maps `8000:8000`, mounts the named volume
`todo-data` at `/data`, has a healthcheck and `restart: unless-stopped`. One command
(`docker compose up -d --build`) replaces the long `docker build` / `docker run` line.

A second file, `docker-compose.scale.yml`, adds an **Nginx** load balancer in front of
several `api` replicas (tutorial Parts 6–7).

### 3.3 automationTesting.py
Written with `pytest` and FastAPI's `TestClient`. A temporary database is used and the table
is emptied before each test, so tests are independent.

| Route | Cases covered |
|-------|---------------|
| `GET /` | returns 200 and `status=running` |
| `GET /health` | returns 200 and `{"status":"healthy"}` |
| `POST /todos` | success (201), missing title (422), empty title (422) |
| `GET /todos` | empty list, list all, filter by `completed` |
| `GET /todos/{id}` | found, not found (404), invalid id (422) |
| `PUT /todos/{id}` | full update, partial update persists, not found (404), invalid title (422) |
| `DELETE /todos/{id}` | success (204 then 404), not found (404) |
| Whole flow | create → read → update → delete |

Total: **18 test functions**.

### 3.4 GitHub Actions pipeline

```
push to main
   │
   ▼
[ test job ]  checkout → setup-python → pip install → python automationTesting.py
   │ (fails → pipeline stops, nothing is pushed)
   ▼
[ build-and-push job ]  checkout → docker login → docker build → docker push
```

- `needs: test` guarantees a broken build is never published.
- `if: github.event_name == 'push'` — pull requests run the tests but never push an image.
- Credentials come from the secrets `DOCKERUSERNAME` and `DOCKERTOKEN`;
  login uses `--password-stdin`.
- Two tags are pushed: `latest` and the commit SHA (traceable, immutable version).

## 4. How to reproduce

See `README.md`. In short:

```bash
python automationTesting.py          # tests
docker compose up -d --build         # run
git push origin main                 # triggers test -> build -> push
```

## 5. Evidence  *(fill in with your own screenshots)*

| # | Evidence | Screenshot |
|---|----------|------------|
| 1 | Local test run: all tests passed | `screenshots/01-tests-local.png` |
| 2 | `docker compose ps` showing the service healthy | `screenshots/02-compose-ps.png` |
| 3 | `curl` of POST / GET `/todos` | `screenshots/03-curl-todos.png` |
| 4 | `docker compose logs` showing structured logs | `screenshots/04-logs.png` |
| 5 | GitHub Actions run with both jobs green | `screenshots/05-actions-success.png` |
| 6 | Docker Hub repository with the new tags | `screenshots/06-dockerhub.png` |
| 7 | (Bonus) Nginx splitting traffic across replicas | `screenshots/07-loadbalancer.png` |

## 6. Observations and challenges

- **Test before publish.** Putting the tests in a separate job with `needs:` makes the
  pipeline a real quality gate instead of just a build script.
- **Secrets.** The token lives only in GitHub Secrets and a git-ignored `.env`; it never
  appears in the repository or image.
- **Persistence.** Container filesystems are temporary, so SQLite's file is stored on a volume.
  Verified by `docker compose down` / `up` — data remains; `down -v` erases it.
- **Scaling limitation.** The scale demo shares one SQLite file between replicas through a
  volume. That works for a demo, but SQLite is not designed for many concurrent writers.
  As the tutorial's Part 1.4 explains, "just adding containers" shifts the bottleneck to the
  database. A production setup would use PostgreSQL (as a separate Compose service) with
  connection pooling.
- **Common failures to watch for** (from the tutorial's cheat sheet): wrong/missing
  `DOCKERTOKEN` → login step fails; wrong username → push "denied"; port already in use →
  change the host port in Compose.

## 7. Conclusion

The project now moves from `git push` to a published, tested Docker image automatically.
Monitoring (structured logs, `/health`), scaling (Compose replicas + Nginx) and CI/CD all
meet at the same artifact — the Docker image — which GitHub Actions builds once and
Docker Hub distributes everywhere.

## 8. Possible improvements

- Swap SQLite for PostgreSQL via a second Compose service.
- Add authentication (JWT) and input rate limiting.
- Add Prometheus metrics and alerting.
- Use `docker/build-push-action` with layer caching to speed up CI.
