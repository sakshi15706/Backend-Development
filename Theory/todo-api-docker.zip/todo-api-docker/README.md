# Todo API — FastAPI · Docker · Compose · GitHub Actions

PBL assignment for **Backend Development, Unit 4** (From Docker to Production).
A small Todo REST API built with FastAPI + SQLite, containerized with Docker, run
with Docker Compose, tested automatically, and shipped to Docker Hub by a
GitHub Actions pipeline.

## Project structure

```
.
├── .github/workflows/ActionsYaml.yaml   # CI/CD: test -> build -> push
├── main.py                              # FastAPI app (CRUD + /health + request logging)
├── automationTesting.py                 # automated tests for every route
├── Dockerfile                           # container image
├── docker-compose.yml                   # run the service (with persistent volume)
├── docker-compose.scale.yml             # bonus: N instances + Nginx load balancer
├── nginx.conf                           # load balancer config (bonus)
├── requirements.txt                     # runtime dependencies
├── requirements-dev.txt                 # + pytest, httpx (for tests)
├── .env.example                         # template for local secrets
├── .dockerignore / .gitignore
├── README.md
└── report.md
```

## API routes

| Method | Path            | Description                          | Success |
|--------|-----------------|--------------------------------------|---------|
| GET    | `/`             | App info                             | 200     |
| GET    | `/health`       | Liveness check                       | 200     |
| GET    | `/todos`        | List todos (`?completed=true/false`) | 200     |
| POST   | `/todos`        | Create a todo                        | 201     |
| GET    | `/todos/{id}`   | Get one todo                         | 200 / 404 |
| PUT    | `/todos/{id}`   | Update (partial updates allowed)     | 200 / 404 |
| DELETE | `/todos/{id}`   | Delete a todo                        | 204 / 404 |

Interactive docs: http://localhost:8000/docs

## 1. Run locally (no Docker)

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
uvicorn main:app --reload
```

## 2. Run the automated tests

```bash
python automationTesting.py
# or
pytest automationTesting.py -v
```
Tests use a temporary SQLite file, so your real data is never touched.

## 3. Run with Docker

```bash
docker build -t <your_docker_username>/todo-api:latest .
docker run --rm -p 8000:8000 <your_docker_username>/todo-api:latest
curl http://localhost:8000/health
```

## 4. Run with Docker Compose

```bash
docker compose up -d --build        # start
docker compose ps                   # status (shows health)
docker compose logs -f api          # structured request logs
docker compose down                 # stop (data kept in the todo-data volume)
docker compose down -v              # stop AND delete data
```

Try it:
```bash
curl -X POST http://localhost:8000/todos \
     -H "Content-Type: application/json" \
     -d '{"title":"Finish PBL","description":"Docker + CI"}'
curl http://localhost:8000/todos
```

### Bonus: horizontal scaling with a load balancer
```bash
docker compose -f docker-compose.scale.yml up -d --build --scale api=2
for i in 1 2 3 4 5 6; do curl -s http://localhost:8080/health; done
docker compose -f docker-compose.scale.yml logs api     # requests split across replicas
docker compose -f docker-compose.scale.yml down
```

## 5. CI/CD with GitHub Actions

Workflow: `.github/workflows/ActionsYaml.yaml`

1. **test** job – installs dependencies and runs `automationTesting.py`.
2. **build-and-push** job – runs **only if tests pass** and only on a push to `main`;
   logs in to Docker Hub, builds the image, pushes `latest` and a `<commit-sha>` tag.

### One-time setup
1. Create a **new** GitHub repository and push this project to it
   (`git init && git add . && git commit -m "Initial commit" && git branch -M main && git remote add origin <url> && git push -u origin main`).
2. Docker Hub → *Account Settings → Security → New Access Token*; copy it.
3. GitHub repo → *Settings → Secrets and variables → Actions → New repository secret*:
   - `DOCKERUSERNAME` = your Docker Hub username
   - `DOCKERTOKEN` = the access token
4. Push a commit and watch the **Actions** tab. The image appears at
   `https://hub.docker.com/r/<your_docker_username>/todo-api`.

### Verify the pushed image
```bash
docker pull <your_docker_username>/todo-api:latest
docker run --rm -p 8000:8000 <your_docker_username>/todo-api:latest
curl http://localhost:8000/
```

## Security notes
- Never commit `.env` or a token. `.gitignore` excludes it.
- Log in with `--password-stdin`, never `docker login -p`.
- The container runs as a non-root user.

## Submission checklist
- [ ] New GitHub repository created, with this code
- [ ] `DOCKERUSERNAME` and `DOCKERTOKEN` secrets added
- [ ] Green workflow run (screenshot in `report.md`)
- [ ] Image visible on Docker Hub (screenshot in `report.md`)
- [ ] Link to this repo added to your main Backend Development repository as **PBL Assignment**
